A Pen created at CodePen.io. You can find this one at https://codepen.io/leonaponce/pen/GYQJQG.

 Show random quotes using "Random Famous Quotes" API
(https://www.mashape.com/andruxnet/random-famous-quotes)

Forked from [Gabriel Nunes](http://codepen.io/hezag/)'s Pen [Random Quote Machine](http://codepen.io/hezag/pen/ZGxOLX/).

Forked from [Free Code Camp](http://codepen.io/FreeCodeCamp/)'s Pen [Random Quote Machine](http://codepen.io/FreeCodeCamp/pen/bELoPJ/).